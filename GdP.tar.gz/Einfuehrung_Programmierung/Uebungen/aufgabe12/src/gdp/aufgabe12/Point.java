package gdp.aufgabe12;

public class Point
{
        public double coordinate[];

        public Point(int dimension) 
        {
                coordinate = new double[dimension];
        }
}
