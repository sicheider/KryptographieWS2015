package gdp.aufgabe12;

public class Punkte
{
        public static void main(String[] args)
        {
                int pointCount;
                int p;
                double distance;
                double closestDistance = Double.MAX_VALUE;
                Point pReference = new Point(3);
                Point pClosest = new Point(3);
                Point pTemp = new Point(3);
                System.out.print("Number of Points: ");
                pointCount = console.InputHelper.readInteger();
                Point[] pointArray = new Point[pointCount];
                System.out.println("Enter Points");
                for(int i = 0; i < pointArray.length; i++)
                {
                        pointArray[i] = new Point(3);
                        System.out.print("p" + (i + 1) + "x: ");
                        pointArray[i].coordinate[0] = console.InputHelper.readDouble();
                        System.out.print("p" + (i + 1) + "y: ");
                        pointArray[i].coordinate[1] = console.InputHelper.readDouble();
                        System.out.print("p" + (i + 1) + "z: ");
                        pointArray[i].coordinate[2] = console.InputHelper.readDouble();
                }
                System.out.print("pxx: ");
                pReference.coordinate[0] = console.InputHelper.readDouble();
                System.out.print("pxy: ");
                pReference.coordinate[1] = console.InputHelper.readDouble();
                System.out.print("pxz: ");
                pReference.coordinate[2] = console.InputHelper.readDouble();
                System.out.print("p-Parameter: ");
                p = console.InputHelper.readInteger();
                for(int i = 0; i < pointArray.length; i++)
                {
                        distance = 0;
                        pTemp.coordinate[0] = pointArray[i].coordinate[0] - pReference.coordinate[0];
                        pTemp.coordinate[1] = pointArray[i].coordinate[1] - pReference.coordinate[1];
                        pTemp.coordinate[2] = pointArray[i].coordinate[2] - pReference.coordinate[2];
                        for(int j = 0; j < 3; j++)
                        {
                                distance = distance + Math.pow(Math.abs(pTemp.coordinate[j]), p);
                        }
                        distance = Math.pow(distance, 1/p);
                        if(distance <= closestDistance)
                        {
                                pClosest = pointArray[i];
                                closestDistance = distance;
                        }
                }
                System.out.print("Closest Point: ");
                System.out.print(pClosest.coordinate[0]);
                System.out.print(",");
                System.out.print(pClosest.coordinate[1]);
                System.out.print(",");
                System.out.print(pClosest.coordinate[2]);
                System.out.print("\n");
                System.out.println("Distance: " + closestDistance);
        }
}
