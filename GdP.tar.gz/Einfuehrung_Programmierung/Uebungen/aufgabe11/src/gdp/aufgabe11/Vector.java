package gdp.aufgabe11;

public class Vector
{
				public double coordinate[];
				public String name;

				public Vector(String _name, int dimension)
				{
								coordinate = new double[dimension];
								for(int i = 0; i < dimension; i++)
								{
												coordinate[i] = 0;
								}
								name = _name;
				}
}
