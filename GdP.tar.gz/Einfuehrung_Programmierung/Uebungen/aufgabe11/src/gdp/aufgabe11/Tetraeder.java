package gdp.aufgabe11;

public class Tetraeder
{
				public static void main(String[] args)
				{
								String vectorNameArray[] = {"a", "b", "c", "d"};
								Vector[] vectorArray = new Vector[vectorNameArray.length];
								for(int i = 0; i < vectorArray.length; i++)
								{
												vectorArray[i] = new Vector(vectorNameArray[i], 3);
								}
								for(int i = 0; i < vectorArray.length; i++)
								{
										    for(int j = 0; j < 3; j++)
                        {
                                System.out.print(vectorArray[i].name + (j + 1) + ": ");
                                vectorArray[i].coordinate[j] = console.InputHelper.readDouble();
                        }
								}
                System.out.println("Volume: "
                                   + VectorMath.volume(VectorMath.vectorSubtraction(vectorArray[1], vectorArray[0]),
                                                       VectorMath.vectorSubtraction(vectorArray[2], vectorArray[0]),
                                                       VectorMath.vectorSubtraction(vectorArray[3], vectorArray[0])));
								System.out.println("Kantenlaenge: "
                                   + VectorMath.edgeLength(VectorMath.vectorSubtraction(vectorArray[1], vectorArray[0]),
                                                           VectorMath.vectorSubtraction(vectorArray[2], vectorArray[0]),
                                                           VectorMath.vectorSubtraction(vectorArray[3], vectorArray[0])));
				}

}
