package gdp.aufgabe11;

public class VectorMath
{
				public static Vector crossProduct(Vector vector1, Vector vector2)
				{
								Vector result = new Vector("result", 3);
								result.coordinate[0] = vector1.coordinate[1] * vector2.coordinate[2] - vector1.coordinate[2] * vector2.coordinate[1];
								result.coordinate[1] = vector1.coordinate[2] * vector2.coordinate[0] - vector1.coordinate[0] * vector2.coordinate[2];
								result.coordinate[2] = vector1.coordinate[0] * vector2.coordinate[1] - vector1.coordinate[1] * vector2.coordinate[0];
								return result;
				}
				
				public static double scalar(Vector vector1, Vector vector2)
				{
								double result;
								result = vector1.coordinate[0] * vector2.coordinate[0]
                       + vector1.coordinate[1] * vector2.coordinate[1]
                       + vector1.coordinate[2] * vector2.coordinate[2];
								return result;
				}

				public static Vector vectorSubtraction(Vector vector1, Vector vector2)
				{
								Vector result = new Vector("result", 3);
								result.coordinate[0] = vector1.coordinate[0] - vector2.coordinate[0];
								result.coordinate[1] = vector1.coordinate[1] - vector2.coordinate[1];
								result.coordinate[2] = vector1.coordinate[2] - vector2.coordinate[2];
								return result;
				}

				public static double vectorAbs(Vector vector)
				{
								double result;
								result = Math.sqrt(Math.pow(vector.coordinate[0], 2)
                                 + Math.pow(vector.coordinate[1], 2)
                                 + Math.pow(vector.coordinate[2], 2));
								return result;
				}

				public static double volume(Vector vector1, Vector vector2, Vector vector3)
				{
								double result;
								result = Math.abs(scalar(crossProduct(vector1, vector2), vector3)) / 6;
								return result;
				}

				public static double edgeLength(Vector vector1, Vector vector2, Vector vector3)
				{
								double result;
								result = (vectorAbs(vector1)
                         + vectorAbs(vector2)
                         + vectorAbs(vector3)
                         + vectorAbs(vectorSubtraction(vector1, vector2))
                         + vectorAbs(vectorSubtraction(vector1, vector3))
                         + vectorAbs(vectorSubtraction(vector2, vector3)));
								return result;
				}
}
