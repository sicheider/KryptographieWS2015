package gdp.aufgabe00;

public class HelloWorld
{
				public static void main(String[] args)
				{
								String name;
								System.out.print("Name: ");
								name = console.InputHelper.readString();
								System.out.print("Hello ");
								System.out.print(name);
								System.out.print("!");
				}
}
