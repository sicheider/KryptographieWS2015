package gdp.aufgabe22;
import java.util.List;
import java.util.ArrayList;

public class XSudoku
{
	public static boolean isPermutation(int[] a)
	{
		boolean result = true;
		List<Integer> alreadyUsed = new ArrayList<Integer>();
		for(int i = 0; i < a.length; i++)
		{
			if(alreadyUsed.contains(a[i]))
			{
				result = false;
				break;
			}
			else
			{
				if(a[i] != 0)
				{
					alreadyUsed.add(a[i]);
				}
			}
		}
		return result;
	}

	public static boolean isPermutationRow(int[][] a, int row)
	{
		int[] b = new int[a[0].length];
		for(int i = 0; i < b.length; i++)
		{
			b[i] = a[row][i];
		}
		boolean result = isPermutation(b);
		return result;
	}

	public static boolean isPermutationCol(int[][] a, int col)
	{
		int[] b = new int[a.length];
		boolean result;
		for(int i = 0; i < b.length; i++)
		{
			b[i] = a[i][col];
		}
		result = isPermutation(b);
		return result;
	}

	public static boolean isPermutationDiagonal(int[][] a)
	{
		int[] b = new int[9];
		int[] c = new int[9];
		boolean result;
		for(int i = 0; i < b.length; i++)
		{
			b[i] = a[i][i];
			c[i] = a[i][8 - i];
		}
		result = isPermutation(b) && isPermutation(c);
		return result;
	}

	public static boolean isPermutationMatrix(int[][] a)
	{
		boolean result = true;
		for(int i = 0; i < a.length; i++)
		{
			result = isPermutationRow(a, i) && isPermutationCol(a, i);
			if(!result)
			{
				break;
			}
		}
		return result;
	}

	public static boolean isPermutationBlock(int[][] a, int minRow, int maxRow, int minCol, int maxCol)
	{
		int rowLength = maxRow - minRow;
		int colLength = maxCol - minCol;
		int blockLength = rowLength * colLength;
		int[] b = new int[blockLength];
		boolean result;
		int tempCount = 0;
		for(int i = minRow; i < maxRow; i++)
		{
			for(int j = minCol; i < maxCol; i++)
			{
				b[tempCount] = a[i][j];
				tempCount++;
			}
		}
		result = isPermutation(b);
		return result;
	}

	public static boolean isPermutationBlocks(int[][] a)
	{
		boolean result = true;
		for(int i = 0; i < 9; i = i + 3)
		{
			for(int j = 0; j < 9; j = j + 3)
			{
				result = isPermutationBlock(a, i, i + 3, j, j + 3);
				if(!result)
				{
					break;
				}
			}
			if(!result)
			{
				break;
			}
		}
		return result;
	}

	public static boolean isValid(int[][] a)
	{
		boolean result = isPermutationMatrix(a)
					  && isPermutationDiagonal(a)
					  && isPermutationBlocks(a);
		return result;
	}

	public static int[][] solve(int[][] a)
	{
		int[][] b = new int[9][9];
		for(int i = 0; i < 9; i++)
		{
			for(int j = 0; j < 9; j++)
			{
				if(a[i][j] == 0)
				{
					for(int k = 1; k <= 9; k++)
					{
						a[i][j] = k;
						if(isValid(a))
						{
							b = solve(a);
							if(b == null)
							{
								continue;
							}
							else
							{
								a = b;
								return a;
							}
						}
					}
					return null;
				}
			}
		}
		return a;
	}

	/*
	public static void main(String[] args)
	{
		int[][] a = {{0,8,7,0,0,0,0,0,0},
					 {5,0,4,0,0,0,0,0,0},
					 {0,0,1,0,7,0,2,0,0},
					 {0,0,9,0,0,0,1,3,0},
					 {2,0,0,0,0,1,0,9,0},
					 {1,0,0,0,0,0,0,0,4},
					 {0,0,0,0,1,9,0,0,0},
					 {0,0,2,7,0,0,0,6,0},
					 {8,9,0,0,0,3,0,0,0}};
		int[][] b = {{9,8,7,1,5,2,3,4,6},
					 {5,2,4,3,9,6,8,7,1},
					 {6,3,1,4,7,8,2,5,9},
					 {7,5,9,8,6,4,1,3,2},
					 {2,4,8,5,3,1,6,9,7},
					 {1,6,3,9,2,7,5,8,4},
					 {3,7,5,6,1,9,4,2,8},
					 {4,1,2,7,8,5,9,6,3},
					 {8,9,6,2,4,3,7,1,5}};
		a = solve(a);
		System.out.println(a == b);
		for(int i = 0; i < 9; i++)
		{
			for(int j = 0; j < 9; j++)
			{
				System.out.print(a[i][j]);
			}
		}
	}
	*/
}
