package gdp.aufgabe21;

public class Palindrom
{
	public static boolean isPalindrome(String word, int beginIndex, int endIndex)
	{
		boolean result = false;
		if(beginIndex == endIndex - 1)
		{
			result = true;
		}
		else
		{
			if(endIndex == beginIndex)
			{
				if(word.charAt(beginIndex) == word.charAt(endIndex - 1))
				{
					result = true;
				}
			}
			else
			{
				if(isPalindrome(word, beginIndex + 1, endIndex - 1)
				&& (word.charAt(beginIndex) == word.charAt(endIndex - 1)))
				{
					result = true;
				}
			}
		}
		return result;
	}

	public static void main(String[] args)
	{
		String word;
		String lowerWord;
		System.out.print("Enter word: ");
		word = console.InputHelper.readString();
		lowerWord = word.toLowerCase();
		if(lowerWord.length() == 0 || isPalindrome(lowerWord, 0, lowerWord.length()))
		{
			System.out.println(word + " is a palindrome.");
		}
		else
		{
			System.out.println(word + " is not a palindrome.");
		}
	}
}
